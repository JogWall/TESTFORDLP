# Demo JavaScript App

[![Coverage Status](https://coveralls.io/repos/github/holidayextras/example-js-project/badge.svg?branch=master)](https://coveralls.io/github/holidayextras/example-js-project?branch=master)
[![Code Climate](https://codeclimate.com/github/holidayextras/example-js-project/badges/gpa.svg)](https://codeclimate.com/github/holidayextras/example-js-project)

An example codebase demonstrating our preferred libraries, recommended project structure and build process setup . This project represents "sensible defaults" or "preferred" ways of doing things. It is NOT the law! If you have a good reason to use or do something differently you should. Note: "its new and shiny" is not, on its own, a good reason to use something different. There is a lot of value in doing things in a consistent way that people are familiar with.

Documentation of these tools and practices can be found in the culture repository. The rest of this readme demonstrates a sample template to be used as a starting point for new projects.

# @TODO Sample Readme
