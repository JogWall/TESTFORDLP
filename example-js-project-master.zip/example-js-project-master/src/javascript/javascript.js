console.log("javascript.js loaded");
