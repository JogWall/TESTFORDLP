var React = require('react');
(<div>
  hello world
</div>);
console.log("javascript_xml.jsx loaded");
