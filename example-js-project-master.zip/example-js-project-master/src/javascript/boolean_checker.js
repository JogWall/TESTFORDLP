'use strict';

module.exports = {

  isTrue: function(subject) {
    return subject === true;
  },

  isFalse: function(subject) {
    return subject === false;
  }

};
